#include <Wire.h>
#include <7Semi_BME68x.h>

#define SDA_PIN 8
#define SCL_PIN 9

BME68x_7Semi sensor;

void setup() {
  Serial.begin(115200);
  delay(1000);

  Wire.begin(SDA_PIN, SCL_PIN);

  Serial.println();
  Serial.println("==============================");
  Serial.println("       BME68x TEST");
  Serial.println("==============================");

  if (!sensor.begin(0x76)) {
    Serial.println("BME68x sensor not detected!");
    while (1);
  }

  Serial.println("BME68x initialized successfully!");
}

void loop() {
  float temperature;
  float humidity;
  float pressure;
  float gas;

  if (sensor.getData(temperature, humidity, pressure, gas)) {

    Serial.println();
    Serial.println("------ BME68x DATA ------");

    Serial.print("Temperature: ");
    Serial.print(temperature, 2);
    Serial.println(" °C");

    Serial.print("Humidity: ");
    Serial.print(humidity, 2);
    Serial.println(" %");

    Serial.print("Pressure: ");
    Serial.print(pressure, 2);
    Serial.println(" hPa");

    Serial.print("Gas Resistance: ");
    Serial.print(gas, 2);
    Serial.println(" Ω");

  } else {
    Serial.println("Failed to read BME68x!");
  }

  delay(2000);
}